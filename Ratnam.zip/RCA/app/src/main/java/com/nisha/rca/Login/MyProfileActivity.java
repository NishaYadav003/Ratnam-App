package com.nisha.rca.Login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.nisha.rca.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import java.util.HashMap;
import java.util.Map;

public class MyProfileActivity extends AppCompatActivity {
    private ImageView profileImageView;
    private FloatingActionButton addButton;
    private Toolbar toolbar;

    private DatabaseReference databaseRef;
    private static final int PICK_IMAGE_REQUEST = 1;
    private boolean isProfileImageClicked = false;
    private Uri profileImageUri;
    private TextView usernameTextView;
    private Button btnSave;
    private EditText edtRollno;
    private EditText editDegree;
    private EditText editContact;

    private StorageReference storageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        profileImageView = findViewById(R.id.imageView8);
        addButton = findViewById(R.id.floatingActionButton2);
        usernameTextView = findViewById(R.id.textView7);
        btnSave = findViewById(R.id.btnSave);
        edtRollno = findViewById(R.id.editRollno);
        editDegree = findViewById(R.id.edtdegree);
        editContact = findViewById(R.id.editContact);
        btnSave = findViewById(R.id.btnSave);
        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();
        databaseRef = FirebaseDatabase.getInstance().getReference();
        Toolbar toolbar = findViewById(R.id.appbarP);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("My Profile");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
        ImageView imageView4 = findViewById(R.id.imageView4);
        imageView4.setImageResource(R.drawable.n);

        
        loadSavedData();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String username = user.getDisplayName();
            usernameTextView.setText("Name:  " + username);
            usernameTextView.setTextColor(getResources().getColor(R.color.textColor));
        } else {
            usernameTextView.setText("Name:");
            usernameTextView.setTextColor(getResources().getColor(R.color.textColor));
        }

        if (user != null) {
            String userId = user.getUid();
            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference();
            databaseRef.child("users").child(userId).child("profileImageUrl").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        String profileImageUrl = dataSnapshot.getValue(String.class);
                        setRoundedImage(profileImageView, profileImageUrl, 400, 400);
                    } else {
                        profileImageView.setImageResource(R.drawable.icon);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MyProfileActivity.this, "Error fetching profile image URL from database", Toast.LENGTH_SHORT).show();
                }
            });
        }
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isProfileImageClicked = true;
                openImagePicker();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isEditable = btnSave.isEnabled();
                setEditTextsEditable(!isEditable);
                updateEditButtonLabel();
                if (isEditable) {
                    saveUpdatedInfoToDatabase();
                }
            }
        });
    }

    private void loadSavedData() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference userRef = databaseRef.child("users").child(userId);

            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);

                        if (userProfile != null) {
                            edtRollno.setText(userProfile.getRollNo());
                            editDegree.setText(userProfile.getDegree());
                            editContact.setText(userProfile.getContactInfo());
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MyProfileActivity.this, "Error loading saved data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();

            if (isProfileImageClicked) {
                profileImageUri = imageUri;
                setRoundedImage(profileImageView, imageUri.toString(), 400, 400);
                uploadImage("profileImage.jpg", profileImageUri);
            }
        }
    }

    private void uploadImage(String imageName, Uri imageUri) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Uploading Image...");
        progressDialog.show();
        StorageReference imageRef = storageRef.child("images/" + imageName);

        imageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String imageUrl = uri.toString();
                        saveImageUrlToDatabase(imageUrl, imageName);
                        progressDialog.dismiss();
                    });
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, "Image upload failed: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                })
                .addOnProgressListener(snapshot -> {
                    double progressPercent = (100.00 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount());
                    progressDialog.setMessage("Progress: " + (int) progressPercent + "%");
                });
    }

    private void saveImageUrlToDatabase(String imageUrl, String imageName) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("users").child(userId);

            if (imageName.equals("profileImage.jpg")) {
                databaseRef.child("profileImageUrl").setValue(imageUrl)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, "Profile Image URL saved to database", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Profile Image URL could not be saved to database: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
            }
        }
    }

    // Helper method to apply rounded transformation to the image
    private void setRoundedImage(ImageView imageView, String imageUrl, int width, int height) {
        Picasso.get()
                .load(imageUrl)
                .resize(width, height)
                .centerCrop()
                .transform(new RoundedTransformation())
                .into(imageView);
    }

    // Custom Picasso Transformation to create rounded images
    public class RoundedTransformation implements Transformation {

        @Override
        public Bitmap transform(Bitmap source) {
            int size = Math.min(source.getWidth(), source.getHeight());

            Bitmap squaredBitmap = Bitmap.createBitmap(source, (source.getWidth() - size) / 2, (source.getHeight() - size) / 2, size, size);
            if (squaredBitmap != source) {
                source.recycle();
            }

            Bitmap bitmap = Bitmap.createBitmap(size, size, source.getConfig());

            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint();
            BitmapShader shader = new BitmapShader(squaredBitmap, BitmapShader.TileMode.CLAMP, BitmapShader.TileMode.CLAMP);
            paint.setShader(shader);
            paint.setAntiAlias(true);

            float r = size / 2f;
            canvas.drawCircle(r, r, r, paint);

            squaredBitmap.recycle();
            return bitmap;
        }

        @Override
        public String key() {
            return "rounded";
        }
    }

    private void setEditTextsEditable(boolean isEditable) {
        edtRollno.setEnabled(isEditable);
        editDegree.setEnabled(isEditable);
        editContact.setEnabled(isEditable);
    }

    private void updateEditButtonLabel() {
        boolean isEditable = btnSave.isEnabled();
        if (isEditable) {
            btnSave.setText("Save Info");
        } else {
            btnSave.setText("Edit Info");
        }
    }

    private void saveUpdatedInfoToDatabase() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userId = user.getUid();

            String rollNo = edtRollno.getText().toString().trim();
            String degree = editDegree.getText().toString().trim();
            String contactInfo = editContact.getText().toString().trim();

            Map<String, Object> updates = new HashMap<>();
            updates.put("rollNo", rollNo);
            updates.put("degree", degree);
            updates.put("contactInfo", contactInfo);

            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("users").child(userId);
            databaseRef.updateChildren(updates)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Information saved", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to save information: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

package com.nisha.rca.About;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.nisha.rca.R;

public class FounderActivity extends AppCompatActivity {
    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.founder);

        imageView = findViewById(R.id.varadarajan);
        imageView.setImageResource(R.drawable.varadarajan_sir);

        textView = findViewById(R.id.V1);

        // Find the Toolbar and set it as the support action bar
        Toolbar toolbar = findViewById(R.id.appbarFounder);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Set the title of the toolbar
        getSupportActionBar().setTitle("Founder President Desk");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle back button click here
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package com.nisha.rca.UplaodAssignment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nisha.rca.R;

public class AssignmentActivity extends AppCompatActivity {

    private static final int PICK_FILE_REQUEST_CODE = 101;
    private Toolbar toolbar;
    private EditText assignmentTitleEditText;
    private Button selectFileButton;
    private TextView selectedFileTextView;
    private Button uploadButton;

    private Uri selectedFileUri;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.assignment_activity);

        assignmentTitleEditText = findViewById(R.id.assignmentTitleEditText);
        selectFileButton = findViewById(R.id.chooseFileButton);
        selectedFileTextView = findViewById(R.id.selectedFileNameTextView);
        uploadButton = findViewById(R.id.uploadButton);
        Toolbar toolbar = findViewById(R.id.appbarU);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Upload Assignment");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
        storageReference = FirebaseStorage.getInstance().getReference();

        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFileChooser();
            }
        });

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadFile();
            }
        });
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // Set the MIME type of files you want to allow (e.g., application/pdf for PDF files)
        startActivityForResult(intent, PICK_FILE_REQUEST_CODE);
    }

    private void uploadFile() {
        if (selectedFileUri != null) {
            StorageReference fileReference = storageReference.child("uploads").child(assignmentTitleEditText.getText().toString());
            fileReference.putFile(selectedFileUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        Toast.makeText(AssignmentActivity.this, "Upload successful", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(AssignmentActivity.this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            selectedFileUri = data.getData();
            selectedFileTextView.setText(selectedFileUri.getLastPathSegment());
        }
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
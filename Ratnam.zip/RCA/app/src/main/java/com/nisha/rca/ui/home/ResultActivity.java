package com.nisha.rca.ui.home;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nisha.rca.R;

import java.util.Objects;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText name;
    private Button resultbtn;
    private DatabaseReference resultRef;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_display);
        Toolbar toolbar = findViewById(R.id.appbarResult);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setTitle("Result");

        // Initialize views
        name = findViewById(R.id.nameEditText);
        resultbtn = findViewById(R.id.resultButton);

        // Set click listener for the result button
        resultbtn.setOnClickListener(this);

        // Initialize the database reference
        resultRef = FirebaseDatabase.getInstance().getReference().child("Results");
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.resultButton:
                String studentName = name.getText().toString().trim();
                if (!studentName.isEmpty()) {
                    // Attach a ValueEventListener to retrieve data for the given student name from the "Results" node in Firebase Realtime Database
                    resultRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            boolean found = false;
                            StringBuilder resultBuilder = new StringBuilder();
                            for (DataSnapshot semesterSnapshot : dataSnapshot.getChildren()) {
                                if (semesterSnapshot.hasChild(studentName)) {
                                    // Student data found under this semester
                                    String result = semesterSnapshot.child(studentName).getValue(String.class);
                                    resultBuilder.append("").append(semesterSnapshot.getKey()).append(": ").append(result).append("\n");
                                    found = true;
                                }
                            }
                            if (found) {
                                // Display the results in an AlertDialog
                                showResultAlertDialog(resultBuilder.toString());
                            } else {
                                // Student data not found
                                showToast("No results found for the given name.");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle errors
                            showToast("Error: " + databaseError.getMessage());
                        }
                    });
                } else {
                    showToast("Please enter a valid name.");
                }
                break;
            default:
                break;
        }
    }

    private void showResultAlertDialog(String resultMessage) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Result");
        builder.setMessage(resultMessage);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, just dismiss the dialog when the "OK" button is clicked
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
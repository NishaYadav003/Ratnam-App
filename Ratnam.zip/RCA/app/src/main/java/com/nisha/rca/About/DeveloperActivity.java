package com.nisha.rca.About;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.nisha.rca.R;

public class DeveloperActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;
    private TextView textView1;
    private TextView textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.developer);

        imageView = findViewById(R.id.devImage);
        imageView.setImageResource(R.drawable.nyimage);
        textView1 = findViewById(R.id.devInfo);
        textView = findViewById(R.id.introText);
        textView2 = findViewById(R.id.devName);
        // Find the Toolbar and set it as the support action bar
        Toolbar toolbar = findViewById(R.id.appbarDEV);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Set the title of the toolbar
        getSupportActionBar().setTitle("Developer");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle back button click here
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
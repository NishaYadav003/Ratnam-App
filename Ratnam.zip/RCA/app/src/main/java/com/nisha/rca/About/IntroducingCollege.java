package com.nisha.rca.About;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.nisha.rca.R;

public class IntroducingCollege extends AppCompatActivity {
    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.introducingcollege);

        imageView = findViewById(R.id.College);
        imageView.setImageResource(R.drawable.sv2);

        textView = findViewById(R.id.collegetext);

        // Find the Toolbar and set it as the support action bar
        Toolbar toolbar = findViewById(R.id.appbarCollege);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Set the title of the toolbar
        getSupportActionBar().setTitle("Introducing Ratnam");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle back button click here
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

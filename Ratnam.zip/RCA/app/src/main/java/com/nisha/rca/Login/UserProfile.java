package com.nisha.rca.Login;

public class UserProfile {
    private String rollNo;
    private String degree;
    private String contactInfo;

    // Default constructor (required by Firebase Realtime Database)
    public UserProfile() {
        // Empty constructor needed for Firebase
    }

    public UserProfile(String rollNo, String degree, String contactInfo) {
        this.rollNo = rollNo;
        this.degree = degree;
        this.contactInfo = contactInfo;
    }

    // Getter and Setter methods for the profile attributes

    // ... (existing code)

    // Additional getters and setters for the profile attributes

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
}


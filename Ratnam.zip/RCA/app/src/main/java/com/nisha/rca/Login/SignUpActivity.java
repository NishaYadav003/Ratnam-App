package com.nisha.rca.Login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.nisha.rca.MainActivity;
import com.nisha.rca.R;

public class SignUpActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private EditText confirmButton;
    private Button buttonSignUp1;
    private TextView txtSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        firebaseAuth = FirebaseAuth.getInstance();

        editTextUsername = findViewById(R.id.edtSignUpFullName);
        editTextEmail = findViewById(R.id.edtSignUpEmail);
        editTextPassword = findViewById(R.id.edtSignUpPassword);
        confirmButton = findViewById(R.id.edtSignUpConfirmPassword);
        buttonSignUp1 = findViewById(R.id.btnSignUp);
        txtSignIn = findViewById(R.id.txtSignIn);

        buttonSignUp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();

                // Validate the input fields
                if (username.isEmpty()) {
                    editTextUsername.setError("Username is required");
                    return;
                }

                if (email.isEmpty()) {
                    editTextEmail.setError("Email is required");
                    return;
                }

                if (password.isEmpty()) {
                    editTextPassword.setError("Password is required");
                    return;
                }

                // Register the user with the provided username, email, and password
                signUpUser(username, email, password);
            }
        });

        txtSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void signUpUser(String username, String email, String password) {
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // User registration successful, go to MainActivity
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            if (user != null) {
                                // Save the username in the user's profile
                                UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                        .setDisplayName(username)
                                        .build();

                                user.updateProfile(profileUpdates)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    goToMyProfileActivity();
                                                } else {
                                                    // Failed to update username in the user's profile
                                                    Toast.makeText(SignUpActivity.this, "Failed to update username in the user's profile.", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                            }
                        } else {
                            // User registration failed, handle the error
                            Toast.makeText(SignUpActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void goToMyProfileActivity() {
        // Launch MyProfileActivity after successful registration
        startActivity(new Intent(SignUpActivity.this, MainActivity.class));
        finish();
    }
}

package com.nisha.rca.ui.notice;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nisha.rca.R;

import java.util.Objects;

public class additionalLayout extends AppCompatActivity {
    private static final int REQUEST_PDF = 1;
    Button button6, button7, button8, button9, button10;
Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.additional_layout);
        toolbar = findViewById(R.id.appbarSubject);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setTitle("Subject");
        toolbar.setTitleTextAppearance(this, R.style.poppins_bold);
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
        button6 = findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("AI Notes.pdf");
            }
        });

        button7 = findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("INS Notes.pdf");
            }
        });

        button8 = findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("STQA Notes.pdf");
            }
        });

        button9 = findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("GP Notes.pdf");
            }
        });

        button10 = findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("PM Notes.pdf");
            }
        });
    }

    private void retrieveAndOpenPDF(String filePath) {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

        // Retrieve the PDF file from Firebase Storage
        storageRef.child(filePath).getDownloadUrl()
                .addOnSuccessListener(uri -> {
                    // File download URL retrieved successfully
                    String downloadUrl = uri.toString();

                    // Call the method to open the PDF file using the download URL
                    openPDF(downloadUrl);
                })
                .addOnFailureListener(e -> {
                    // Handle the failure
                    Toast.makeText(additionalLayout.this, "Failed to retrieve PDF", Toast.LENGTH_SHORT).show();
                });
    }

    private void openPDF(String downloadUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(downloadUrl), "application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(additionalLayout.this, "No PDF viewer application found", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

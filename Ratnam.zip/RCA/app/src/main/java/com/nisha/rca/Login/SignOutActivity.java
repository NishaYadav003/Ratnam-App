package com.nisha.rca.Login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.nisha.rca.R;

public class SignOutActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logoutbutton);

        firebaseAuth = FirebaseAuth.getInstance();

        // Get reference to the yes button
        Button buttonYes = findViewById(R.id.yesButton);

        // Add click listener to the yes button
        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOutUser();
            }
        });

        // Get reference to the no button
        Button buttonNo = findViewById(R.id.noButton);

        // Add click listener to the no button
        buttonNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the user clicks "No," dismiss the dialog and stay on the SignOutActivity
                finish();
            }
        });
    }

    // Method to sign out the user
    private void signOutUser() {
        firebaseAuth.signOut();

        Intent intent = new Intent(SignOutActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


}

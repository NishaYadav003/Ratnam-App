package com.nisha.rca.ui.notice;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.nisha.rca.R;

public class WebViewActivity2 extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webviewactivity1);

        webView = findViewById(R.id.adm);
        webView.setWebViewClient(new WebViewClient());

        String url = "https://mu.ac.in/admission";
        webView.loadUrl(url);
    }
}
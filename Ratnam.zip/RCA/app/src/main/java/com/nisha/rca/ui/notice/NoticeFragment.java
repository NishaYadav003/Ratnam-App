package com.nisha.rca.ui.notice;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.nisha.rca.MainActivity;
import com.nisha.rca.R;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nisha.rca.ui.home.ResultActivity;

public class NoticeFragment extends Fragment {
    private static final int REQUEST_PDF = 1;
    Button button2, button4,button6,button7;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_notice, container, false);

        button2 = v.findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("TYCSSyllabus.pdf");
            }
        });
        button6 = v.findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("ExamTT.pdf");
            }
        });
        Button button7 = v.findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action or open layout
                // For example, open a new activity
                Intent intent = new Intent(getActivity(), ResultActivity.class);
                startActivity(intent);
            }
        });
        Button openWebViewButton3 = v.findViewById(R.id.button3);
        openWebViewButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open WebView activity or fragment
                Intent intent = new Intent(getActivity(), WebViewActivity2.class);
                startActivity(intent);
            }
        });

        button4 = v.findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveAndOpenPDF("ratnam23.pdf");
            }
        });

        Button button5 = v.findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action or open layout
                // For example, open a new activity
                Intent intent = new Intent(getActivity(), additionalLayout.class);
                startActivity(intent);
            }
        });

        return v;
    }

    private void retrieveAndOpenPDF(String filePath) {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

        // Retrieve the PDF file from Firebase Storage
        storageRef.child(filePath).getDownloadUrl()
                .addOnSuccessListener(uri -> {
                    // File download URL retrieved successfully
                    String downloadUrl = uri.toString();

                    // Call the method to open the PDF file using the download URL
                    openPDF(downloadUrl);
                })
                .addOnFailureListener(e -> {
                    // Handle the failure
                    Toast.makeText(getContext(), "Failed to retrieve PDF", Toast.LENGTH_SHORT).show();
                });
    }

    private void openPDF(String downloadUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(downloadUrl), "application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getContext(), "No PDF viewer application found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity) getActivity()).setActionBarTitle("Notice");
    }
}

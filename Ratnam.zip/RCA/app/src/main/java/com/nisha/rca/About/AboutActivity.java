package com.nisha.rca.About;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.nisha.rca.R;

import java.util.Objects;

public class AboutActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private ImageButton collegeButton, founderButton, directorButton, principalButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        toolbar = findViewById(R.id.appbarAbout);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setTitle("About");
        toolbar.setTitleTextAppearance(this, R.style.poppins_bold);
        collegeButton = findViewById(R.id.college);
        founderButton = findViewById(R.id.founder);
        directorButton = findViewById(R.id.director);
        principalButton = findViewById(R.id.principal);
        collegeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle college image button click here
                Intent intent = new Intent(AboutActivity.this, IntroducingCollege.class);
                startActivity(intent);
            }
        });

        founderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle founder image button click here
                Intent intent = new Intent(AboutActivity.this, FounderActivity.class);
                startActivity(intent);
            }
        });

        directorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle director image button click here
                Toast.makeText(AboutActivity.this, "Uh Oh! Message not Available", Toast.LENGTH_SHORT).show();
            }
        });

        principalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle principal image button click here
                Intent intent = new Intent(AboutActivity.this, PrincipalActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

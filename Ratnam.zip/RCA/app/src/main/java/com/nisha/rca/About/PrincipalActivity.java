package com.nisha.rca.About;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.nisha.rca.R;

public class PrincipalActivity extends AppCompatActivity {
    private ImageView imageView;
    private TextView textView;
    private TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);

        imageView = findViewById(R.id.principal);
        imageView.setImageResource(R.drawable.principalincharge);

        textView = findViewById(R.id.pricipaltext);
        textView1 = findViewById(R.id.besttext);



        // Find the Toolbar and set it as the support action bar
        Toolbar toolbar = findViewById(R.id.appbarPrincipal);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Set the title of the toolbar
        getSupportActionBar().setTitle("Principal's Desk");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle back button click here
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

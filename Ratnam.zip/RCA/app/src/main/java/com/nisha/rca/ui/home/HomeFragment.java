package com.nisha.rca.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nisha.rca.MainActivity;
import com.nisha.rca.R;
import com.nisha.rca.ui.branch.BranchAdapter;
import com.nisha.rca.ui.branch.BranchModel;
import com.nisha.rca.ui.events.EventAdapter;
import com.nisha.rca.ui.events.EventData;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private int[] images;
    private String[] text;
    private SliderAdapter adapter;
    private SliderView sliderView;
    private ImageView map;
    private ViewPager viewPager;
    private BranchAdapter branchAdapter;
    private List<BranchModel> list;
    private RecyclerView eventRV;

    EventAdapter eventAdapter;
    private DatabaseReference reference;
    private List<EventData> eventDataList;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    @Keep
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        list = new ArrayList<>();

        // Adding branch data
        list.add(new BranchModel(R.drawable.cse_icon, "BSC Computer Science (BSC CS)"));
        list.add(new BranchModel(R.drawable.cse_icon, "BSC Information Technology (BSC IT)"));
        list.add(new BranchModel(R.drawable.cse_icon, "Bachelor of Science (BSC)"));
        list.add(new BranchModel(R.drawable.cse_icon, "Bachelor of Commerce (Banking and insurance)"));
        list.add(new BranchModel(R.drawable.cse_icon, "Bachelor of Commerce (Accounting and finance)"));
        list.add(new BranchModel(R.drawable.cse_icon, "Bachelor of Management Studies"));
        list.add(new BranchModel(R.drawable.cse_icon, "B.Com"));
        list.add(new BranchModel(R.drawable.faculty_icon, "Bachelor of Arts (BA)"));

        list.add(new BranchModel(R.drawable.aero_icon, "MSc Physics"));
        list.add(new BranchModel(R.drawable.bio_icon, "MSc Chemistry"));

        list.add(new BranchModel(R.drawable.cse_icon, "M.com"));
        list.add(new BranchModel(R.drawable.bio_icon, "PhD in Botany"));
        list.add(new BranchModel(R.drawable.aero_icon, "PhD in Physics"));
        list.add(new BranchModel(R.drawable.cse_icon, "PhD in Commerce"));

        // Initialize the BranchAdapter
        branchAdapter = new BranchAdapter(getContext(), list);

        // Find and set up the ViewPager
        viewPager = view.findViewById(R.id.viewpager);
        viewPager.setAdapter(branchAdapter);

        eventRV = view.findViewById(R.id.eventsRV);
        eventRV.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        reference = FirebaseDatabase.getInstance().getReference().child("Events");
        reference.keepSynced(true);
        getEventData();
        return view;
    }

    private void getEventData() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                eventDataList = new ArrayList<>();
                if (!snapshot.exists()) {
                    eventRV.setVisibility(View.GONE);
                } else {
                    eventRV.setVisibility(View.VISIBLE);
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        EventData data = dataSnapshot.getValue(EventData.class);
                        eventDataList.add(0, data);
                    }
                    eventRV.setHasFixedSize(true);
                    eventRV.setLayoutManager(new LinearLayoutManager(getContext()));
                    eventAdapter = new EventAdapter(eventDataList, getContext());
                    eventRV.setAdapter(eventAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sliderView = view.findViewById(R.id.sliderView);
        // Setting images and text
        images = new int[]{
                R.drawable.sv1,
                R.drawable.sv2,
                R.drawable.outside,
                R.drawable.nvra,
                R.drawable.nara,
                R.drawable.classroom
        };
        text = new String[]{
                "Empowering Students Since 1983",
                "College Entrance",
                "Campus",
                "Auditorium",
                "Library",
                "Classrooms"
        };

        // Creating adapter
        adapter = new SliderAdapter(images, text);
        // Setting adapter in slider view
        sliderView.setSliderAdapter(adapter);
        sliderView.setSliderTransformAnimation(SliderAnimations.FADETRANSFORMATION);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.SLIDE);
        sliderView.startAutoCycle();

        map = view.findViewById(R.id.map);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });
    }

    private void openMap() {
        Uri uri = Uri.parse("geo:0,0?q= NES Ratnam College of Arts, Science and Commerce");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity) getActivity()).setActionBarTitle("Dashboard");
    }
}

// GalleryFragment.java

package com.nisha.rca.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nisha.rca.MainActivity;
import com.nisha.rca.R;

import java.util.ArrayList;
import java.util.List;

public class GalleryFragment extends Fragment {

    private RecyclerView recyclerView;
    private GalleryAdapter galleryAdapter;
    private List<String> imageUrls;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_gallery, container, false);

        // Initialize the RecyclerView and the imageUrls list
        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        imageUrls = new ArrayList<>();

        // Retrieve the photo URLs from Firebase Storage
        retrievePhotosFromFirebaseStorage();

        return rootView;
    }

    private void retrievePhotosFromFirebaseStorage() {
        // Assuming you have a Firebase Storage reference for your images.
        // Replace "images" with the folder name in Firebase Storage where your images are stored.
        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("imageurls");

        // List all items in the "images" folder
        storageRef.listAll().addOnSuccessListener(listResult -> {
            List<StorageReference> items = listResult.getItems();
            if (items != null && !items.isEmpty()) {
                for (StorageReference item : items) {
                    // Get the download URL of each image and add it to the imageUrls list
                    item.getDownloadUrl().addOnSuccessListener(uri -> {
                        imageUrls.add(uri.toString());
                        // Check if the imageUrls list is complete before updating the RecyclerView
                        if (imageUrls.size() == items.size()) {
                            updateRecyclerView();
                        }
                    });
                }
            } else {
                // Handle the case where no images are found
                // For example, show an error message or an empty state in the gallery
            }
        }).addOnFailureListener(exception -> {
            // Handle any exceptions during Firebase Storage retrieval
            // For example, show an error message or a retry option
        });
    }

    private void updateRecyclerView() {
        if (isAdded() && getContext() != null) {
            if (galleryAdapter == null) {
                galleryAdapter = new GalleryAdapter(requireContext(), imageUrls);
                recyclerView.setAdapter(galleryAdapter);
            } else {
                galleryAdapter.notifyDataSetChanged();
            }
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity) requireActivity()).setActionBarTitle("Event Gallery");
    }
}